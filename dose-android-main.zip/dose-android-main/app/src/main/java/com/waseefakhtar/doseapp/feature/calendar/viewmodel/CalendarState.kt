package com.waseefakhtar.doseapp.feature.calendar.viewmodel

import java.util.Date

// TODO: Fill out when Calendar feature is implemented
data class CalendarState(
    val currentDate: Date? = null
)
